#include <stdio.h>
//code for ternary operator
int main() {
    int a = 8; //defination and declaration of int a
    int b = 5; //defination and declaration of int b
    int max;

    // output for operators
    max = (a > b) ? a : b;

    // Display the result
    printf("Maximum value: %d\n", max);

    return 0;
}
