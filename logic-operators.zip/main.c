#include <stdio.h>
//code for Logical operator
int main() {
    int a = 10; //declaration and defination of int a 
    int b = 50; //declaration and defination of int b
    int c = 34; //declaration and defination of int c

    // output of operators
    printf("a = %d, b = %d, c = %d\n", a, b, c);
    printf("(a > b) && (b > c): %d\n", (a > b) && (b > c));  // Logical AND
    printf("(a > b) || (b == c): %d\n", (a > b) || (b == c)); // Logical OR
    printf("!(a == c): %d\n", !(a == c));                    // Logical NOT

    return 0;
}

