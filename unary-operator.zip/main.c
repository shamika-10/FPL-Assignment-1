#include<stdio.h>
int main() {
    int a = 10;
     a++;      // Post-increment
    printf("Post-increment of a is %d\n", a);

    a--;      // Post-decrement
    printf("Post-decrement of a is %d\n", a);

    return 0;
}