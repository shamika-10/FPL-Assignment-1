#include <stdio.h>
// code for assignment operator
int main() {
    int a = 12; //defination and declaration of int a
    int b = 55; //defination and declaration of int b
    //output of operators
    printf("Initial values: a = %d, b = %d\n", a, b);

    a = b;       // Simple assignment
    printf("a = b -> a = %d\n", a);
    
    a += b;      // Add and assign
    printf("a += b -> a = %d\n", a);
    
    a -= b;      // Subtract and assign
    printf("a -= b -> a = %d\n", a);
    
    a *= b;      // Multiply and assign
    printf("a *= b -> a = %d\n", a);
    
    a /= b;      // Divide and assign
    printf("a /= b -> a = %d\n", a);
    
    a %= b;      // Modulus and assign
    printf("a %%= b -> a = %d\n", a);

    return 0;
}

