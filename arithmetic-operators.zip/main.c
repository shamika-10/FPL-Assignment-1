#include <stdio.h>
//code for arthimetic operators
int main() {
    int a = 10; //declaration and defination of int a 
    int b = 15; //declaration and defination of int b
    int add, subtract, multiply, divide, mod;
    //declaration of operators
    
    //defination of operators
    add = a + b;         // Addition
    subtract = a - b;    // Subtraction
    multiply = a * b;    // Multiplication
    divide = a / b;      // Division
    mod = a % b;         // Modulus

    // printing the output
    printf(" %d\n",add);
    printf("%d\n",subtract);
    printf("%d\n", multiply);
    printf(" %d\n",divide);
    printf(" %d\n",mod);

    return 0;
}

