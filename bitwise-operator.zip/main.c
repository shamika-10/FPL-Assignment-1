#include <stdio.h>
//code for bitwise operators
int main() {
    int a = 12; // declaration and defination of int a
    int b = 5;  // declaration and defination of int b

    // output of operators
    printf("a & b: %d\n", a & b);  // AND
    printf("a | b: %d\n", a | b);  // OR
    printf("a ^ b: %d\n", a ^ b);  // XOR
    printf("~a: %d\n", ~a);        // NOT
    printf("a << 1: %d\n", a << 1); // Left shift
    printf("a >> 1: %d\n", a >> 1); // Right shift

    return 0;
}
